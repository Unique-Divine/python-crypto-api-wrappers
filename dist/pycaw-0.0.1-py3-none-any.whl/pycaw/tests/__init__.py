"""Tests for the crypto_apis package."""
import dotenv
dotenv.load_dotenv()
