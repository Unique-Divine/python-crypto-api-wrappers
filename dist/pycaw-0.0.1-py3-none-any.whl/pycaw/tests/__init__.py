"""Tests for the pycaw package."""
import dotenv
dotenv.load_dotenv()
