"""Module to handle initialization, imports, for DeFiLlama class"""


from .defillama import *
