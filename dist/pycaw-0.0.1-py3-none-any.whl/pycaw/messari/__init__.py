"""Module to handle initialization, imports, for Messari class"""

# https://github.com/messari/messari-python-api

from crypto_apis.messari.messari_api import *
