"""External API wrappers for Coin Market Cap, Messari, and Etherscan."""
import dotenv
dotenv.load_dotenv()